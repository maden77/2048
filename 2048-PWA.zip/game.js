let grid = [], score = 0, best = localStorage.getItem('best') || 0;
const gridElement = document.getElementById('grid');
const scoreElement = document.getElementById('score');
const bestElement = document.getElementById('best');
const gameOverScreen = document.getElementById('gameOver');
const gameOverText = document.getElementById('gameOverText');
const tileSound = new Audio('audio/tile.wav');
const mergeSound = new Audio('audio/merge.wav');

function init() {
  grid = Array(4).fill().map(() => Array(4).fill(0));
  score = 0;
  updateScore();
  gameOverScreen.classList.remove('show');
  drawGrid();
  addTile(); addTile();
}

function updateScore() {
  scoreElement.textContent = score;
  if (score > best) {
    best = score;
    bestElement.textContent = best;
    localStorage.setItem('best', best);
  }
}

function drawGrid() {
  gridElement.innerHTML = '';
  for (let row = 0; row < 4; row++) {
    for (let col = 0; col < 4; col++) {
      const cell = document.createElement('div');
      cell.className = 'cell';
      const value = grid[row][col];
      if (value) {
        const tile = document.createElement('div');
        tile.className = `tile tile-${value}`;
        tile.textContent = value;
        cell.appendChild(tile);
      }
      gridElement.appendChild(cell);
    }
  }
}

function addTile() {
  const empty = [];
  for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) {
    if (grid[r][c] === 0) empty.push([r, c]);
  }
  if (empty.length === 0) return;
  const [r, c] = empty[Math.floor(Math.random() * empty.length)];
  grid[r][c] = Math.random() < 0.9 ? 2 : 4;
  tileSound.play();
  drawGrid();
}

function slide(row) {
  row = row.filter(v => v);
  for (let i = 0; i < row.length - 1; i++) {
    if (row[i] === row[i + 1]) {
      row[i] *= 2;
      score += row[i];
      row[i + 1] = 0;
      mergeSound.play();
    }
  }
  return row.filter(v => v).concat(Array(4 - row.filter(v => v).length).fill(0));
}

function rotateGrid(clockwise = true) {
  const newGrid = Array(4).fill().map(() => Array(4).fill(0));
  for (let r = 0; r < 4; r++)
    for (let c = 0; c < 4; c++)
      newGrid[c][3 - r] = clockwise ? grid[r][c] : grid[3 - c][r];
  grid = newGrid;
}

function move(dir) {
  let moved = false;
  for (let i = 0; i < ({ up:1, right:2, down:3 }[dir] || 0); i++) rotateGrid();
  for (let r = 0; r < 4; r++) {
    const original = grid[r].slice();
    grid[r] = slide(grid[r]);
    if (!moved && grid[r].join() !== original.join()) moved = true;
  }
  for (let i = 0; i < ({ up:3, right:2, down:1 }[dir] || 0); i++) rotateGrid();
  if (moved) {
    addTile();
    updateScore();
    if (checkGameOver()) showGameOver();
  }
}

function checkGameOver() {
  for (let r = 0; r < 4; r++)
    for (let c = 0; c < 4; c++) {
      if (grid[r][c] === 0) return false;
      if (c < 3 && grid[r][c] === grid[r][c + 1]) return false;
      if (r < 3 && grid[r][c] === grid[r + 1][c]) return false;
    }
  return true;
}

function showGameOver() {
  gameOverText.textContent = "Game Over!";
  gameOverScreen.classList.add('show');
}

document.addEventListener('keydown', e => {
  if (e.key.includes('Arrow')) {
    move(e.key.replace('Arrow', '').toLowerCase());
    e.preventDefault();
  }
});

let startX, startY;
document.addEventListener('touchstart', e => {
  const t = e.touches[0];
  startX = t.clientX;
  startY = t.clientY;
}, { passive: true });

document.addEventListener('touchend', e => {
  if (startX === undefined || startY === undefined) return;
  const t = e.changedTouches[0];
  const dx = t.clientX - startX;
  const dy = t.clientY - startY;
  if (Math.abs(dx) > Math.abs(dy)) {
    if (dx > 30) move('right');
    else if (dx < -30) move('left');
  } else {
    if (dy > 30) move('down');
    else if (dy < -30) move('up');
  }
  startX = startY = undefined;
}, { passive: true });

init();